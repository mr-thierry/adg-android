ActionBarSherlock Test App
==========================

Individual activities which each set up and provide interaction methods for a
specific test case.

Each activity has a name which provides insight into the what it is testing. If
you are providing new activities to test please follow the same naming
conventions that are already in use.
